namespace Coffee_Shop_M.S
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (namecombo.SelectedItem.ToString() == "Latte")
            {
                if (Typecombo.SelectedItem.ToString() == "Ice")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.2).ToString();
                }
                if (Typecombo.SelectedItem.ToString() == "Frappe")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.0).ToString();
                }
                if (Typecombo.SelectedItem.ToString() == "Hot")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 0.90).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if (namecombo.SelectedItem.ToString() == "Espresso")
            {
                if (Typecombo.SelectedItem.ToString() == "Long")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.0).ToString();
                }
                if (Typecombo.SelectedItem.ToString() == "Short")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * .70).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if (namecombo.SelectedItem.ToString() == "Black Coffee")
            {
                if (Typecombo.SelectedItem.ToString() == "Big")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.50).ToString();
                }
                if (Typecombo.SelectedItem.ToString() == "Small")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.20).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if (namecombo.SelectedItem.ToString() == "Cappuccino")
            {
                if (Typecombo.SelectedItem.ToString()== "Frappe")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.70).ToString();
                }
                if (Typecombo.SelectedItem.ToString()=="Ice")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.50).ToString();
                }
                if (Typecombo.SelectedItem.ToString() =="Hot")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.30).ToString();
                }
                 dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if(namecombo.SelectedItem.ToString() == "Macchiato")
            {
                if (Typecombo.SelectedItem.ToString() =="Big")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.50).ToString();
                }
                if (Typecombo.SelectedItem.ToString()=="Small")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 1.30).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if(namecombo.SelectedItem.ToString() =="Frappe")
            {
                if(Typecombo.SelectedItem.ToString() =="Frappe")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 2.0).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);
            }
            else if(namecombo.SelectedItem.ToString() =="Chocolate")
            {
                if(Typecombo.SelectedItem.ToString() =="Hot")
                {
                    paymenttext.Text = (float.Parse(quantitycombo.Text) * 2.20).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, Typecombo.Text, quantitycombo.Text, paymenttext.Text);

            }

        }

        private void idtext_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (Char)Keys.Back;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            idtext.Text = "";
            namecombo.Text = "";
            Typecombo.Text = "";
            quantitycombo.Text = "";
            paymenttext.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
